import { Routes, Route } from "react-router-dom";

import Notes from "./pages/Notes";
import "./App.css";
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";

import Dashboard from "./pages/Dashboard";
import Attendance from "./pages/Attendance";
import Assignment from "./pages/Assignment";

function App() {
  return (
    <div className="app">

      <Sidebar />

      <div className="main">

        <Navbar />

        <div className="content">
          <Routes>

            <Route path="/" element={<Dashboard />} />

            <Route path="/attendance" element={<Attendance />} />

            <Route path="/assignments" element={<Assignment />} />

            <Route path="/notes" element={<Notes />} />

          </Routes>
        </div>

      </div>

    </div>
  );
}

export default App;