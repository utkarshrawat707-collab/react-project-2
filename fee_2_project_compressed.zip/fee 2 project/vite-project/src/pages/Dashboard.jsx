
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  FaClipboardCheck,
  FaTasks,
  FaBook,
  FaClock
} from "react-icons/fa";

function Dashboard() {
  const navigate = useNavigate();

  const [overallAttendance, setOverallAttendance] = useState(0);
  const [pendingAssignments, setPendingAssignments] = useState(0);
  const [totalAssignments, setTotalAssignments] = useState(0);

  useEffect(() => {
    const loadAttendance = () => {
      const savedSubjects = localStorage.getItem("attendanceSubjects");

      if (savedSubjects) {
        const subjects = JSON.parse(savedSubjects);

        const totalAttended = subjects.reduce(
          (sum, subject) => sum + subject.attended,
          0
        );

        const totalClasses = subjects.reduce(
          (sum, subject) => sum + subject.total,
          0
        );

        const percentage =
          totalClasses === 0
            ? 0
            : Math.round((totalAttended / totalClasses) * 100);

        setOverallAttendance(percentage);
      } else {
        setOverallAttendance(0);
      }
    };

    const loadAssignments = () => {
      const savedAssignments = localStorage.getItem("studentAssignments");

      if (savedAssignments) {
        const assignments = JSON.parse(savedAssignments);

        setTotalAssignments(assignments.length);

        setPendingAssignments(
          assignments.filter(
            (assignment) => !assignment.completed
          ).length
        );
      } else {
        setTotalAssignments(0);
        setPendingAssignments(0);
      }
    };

    loadAttendance();
    loadAssignments();

    window.addEventListener("focus", loadAttendance);
    window.addEventListener("attendanceUpdated", loadAttendance);

    window.addEventListener("focus", loadAssignments);
    window.addEventListener("assignmentsUpdated", loadAssignments);

    return () => {
      window.removeEventListener("focus", loadAttendance);
      window.removeEventListener("attendanceUpdated", loadAttendance);

      window.removeEventListener("focus", loadAssignments);
      window.removeEventListener("assignmentsUpdated", loadAssignments);
    };
  }, []);

  const assignmentProgress =
    totalAssignments === 0
      ? 0
      : Math.round(
          ((totalAssignments - pendingAssignments) / totalAssignments) * 100
        );

  return (
    <div>
      <div className="welcome">
        <h2>Good Evening! 👋</h2>
        <p>Here's an overview of your academic progress.</p>
      </div>

      <div className="stats-grid">
        <div
          className="stat-card"
          onClick={() => navigate("/attendance")}
          style={{ cursor: "pointer" }}
        >
          <div className="stat-icon attendance-icon">
            <FaClipboardCheck />
          </div>

          <div>
            <p>Attendance</p>
            <h2>{overallAttendance}%</h2>
          </div>
        </div>

        <div
          className="stat-card"
          onClick={() => navigate("/assignments")}
          style={{ cursor: "pointer" }}
        >
          <div className="stat-icon assignment-icon">
            <FaTasks />
          </div>

          <div>
            <p>Pending Assignments</p>
            <h2>{pendingAssignments}</h2>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon notes-icon">
            <FaBook />
          </div>

          <div>
            <p>Notes</p>
            <h2>12</h2>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon study-icon">
            <FaClock />
          </div>

          <div>
            <p>Study Hours</p>
            <h2>24h</h2>
          </div>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="panel">
          <div className="panel-header">
            <h3>Today's Classes</h3>
            <span>Monday</span>
          </div>

          <div className="class-item">
            <div>
              <strong>Data Structures</strong>
              <p>Room 204</p>
            </div>
            <span>10:00 AM</span>
          </div>

          <div className="class-item">
            <div>
              <strong>Database Management</strong>
              <p>Room 301</p>
            </div>
            <span>12:00 PM</span>
          </div>

          <div className="class-item">
            <div>
              <strong>Web Development</strong>
              <p>Lab 2</p>
            </div>
            <span>2:00 PM</span>
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <h3>Today's Progress</h3>
          </div>

          <div className="progress-container">
            <div className="progress-label">
              <span>Assignments Completed</span>
              <span>{assignmentProgress}%</span>
            </div>

            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${assignmentProgress}%` }}
              ></div>
            </div>
          </div>

          <div className="progress-container">
            <div className="progress-label">
              <span>Attendance</span>
              <span>{overallAttendance}%</span>
            </div>

            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${overallAttendance}%` }}
              ></div>
            </div>
          </div>

          <div className="progress-container">
            <div className="progress-label">
              <span>Daily Goals</span>
              <span>60%</span>
            </div>

            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: "60%" }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
