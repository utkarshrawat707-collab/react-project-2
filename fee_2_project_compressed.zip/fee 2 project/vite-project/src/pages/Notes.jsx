
import { useState, useEffect } from "react";
import { FaPlus, FaTrash, FaEdit, FaSave, FaSearch } from "react-icons/fa";

function Notes() {
  const [notes, setNotes] = useState(() => {
    const savedNotes = localStorage.getItem("studentNotes");
    return savedNotes ? JSON.parse(savedNotes) : [];
  });

  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [content, setContent] = useState("");
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    localStorage.setItem("studentNotes", JSON.stringify(notes));
  }, [notes]);

  function handleSubmit(e) {
    e.preventDefault();

    if (title.trim() === "" || subject.trim() === "" || content.trim() === "") {
      alert("Please fill in all fields.");
      return;
    }

    if (editingId !== null) {
      const updatedNotes = notes.map((note) => {
        if (note.id === editingId) {
          return {
            ...note,
            title: title,
            subject: subject,
            content: content
          };
        }

        return note;
      });

      setNotes(updatedNotes);
      setEditingId(null);
    } else {
      const newNote = {
        id: Date.now(),
        title: title,
        subject: subject,
        content: content,
        date: new Date().toLocaleDateString()
      };

      setNotes([...notes, newNote]);
    }

    setTitle("");
    setSubject("");
    setContent("");
  }

  function editNote(note) {
    setTitle(note.title);
    setSubject(note.subject);
    setContent(note.content);
    setEditingId(note.id);
  }

  function deleteNote(id) {
    setNotes(notes.filter((note) => note.id !== id));

    if (editingId === id) {
      cancelEdit();
    }
  }

  function cancelEdit() {
    setEditingId(null);
    setTitle("");
    setSubject("");
    setContent("");
  }

  const filteredNotes = notes.filter((note) => {
    return (
      note.title.toLowerCase().includes(search.toLowerCase()) ||
      note.subject.toLowerCase().includes(search.toLowerCase()) ||
      note.content.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="notes-page">
      <div className="notes-heading">
        <h2>My Notes</h2>
        <p>Save your important study notes in one place.</p>
      </div>

      <div className="notes-stats">
        <div className="notes-stat-card">
          <h3>{notes.length}</h3>
          <p>Total Notes</p>
        </div>
      </div>

      <div className="notes-form-card">
        <h3>{editingId !== null ? "Edit Note" : "Create a Note"}</h3>

        <form onSubmit={handleSubmit}>
          <div className="notes-form-grid">
            <div className="notes-field">
              <label>Note Title</label>
              <input
                type="text"
                placeholder="Enter note title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div className="notes-field">
              <label>Subject</label>
              <input
                type="text"
                placeholder="e.g. Java, React, DBMS"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
            </div>
          </div>

          <div className="notes-field">
            <label>Note Content</label>
            <textarea
              placeholder="Write your notes here..."
              rows="5"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
          </div>

          <div className="notes-form-buttons">
            <button type="submit" className="notes-save-btn">
              {editingId !== null ? <FaSave /> : <FaPlus />}
              {editingId !== null ? " Update Note" : " Add Note"}
            </button>

            {editingId !== null && (
              <button
                type="button"
                className="notes-cancel-btn"
                onClick={cancelEdit}
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="notes-list-section">
        <div className="notes-list-heading">
          <h3>Saved Notes</h3>

          <div className="notes-search">
            <FaSearch />
            <input
              type="text"
              placeholder="Search notes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        {filteredNotes.length === 0 ? (
          <p className="notes-empty">
            {notes.length === 0
              ? "No notes yet. Create your first note above!"
              : "No notes match your search."}
          </p>
        ) : (
          <div className="notes-list">
            {filteredNotes.map((note) => (
              <div className="note-card" key={note.id}>
                <div className="note-card-heading">
                  <div>
                    <h4>{note.title}</h4>
                    <span className="note-subject">{note.subject}</span>
                  </div>

                  <div className="note-actions">
                    <button
                      type="button"
                      className="note-edit-btn"
                      onClick={() => editNote(note)}
                      aria-label="Edit note"
                      title="Edit note"
                    >
                      <FaEdit />
                    </button>

                    <button
                      type="button"
                      className="note-delete-btn"
                      onClick={() => deleteNote(note.id)}
                      aria-label="Delete note"
                      title="Delete note"
                    >
                      <FaTrash />
                    </button>
                  </div>
                </div>

                <p className="note-content">{note.content}</p>
                <small className="note-date">Created: {note.date}</small>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Notes;
