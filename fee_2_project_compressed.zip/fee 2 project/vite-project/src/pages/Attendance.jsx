import { useEffect, useState } from "react";

import {
  FaPlus,
  FaTrash,
  FaCheckCircle
} from "react-icons/fa";


function Attendance() {

  const defaultSubjects = [
    {
      id: 1,
      name: "Data Structures",
      attended: 18,
      total: 20
    },

    {
      id: 2,
      name: "Database Management",
      attended: 16,
      total: 20
    },

    {
      id: 3,
      name: "Web Development",
      attended: 19,
      total: 20
    },

    {
      id: 4,
      name: "Operating Systems",
      attended: 14,
      total: 18
    }
  ];


  const [subjects, setSubjects] = useState(() => {

    const savedSubjects = localStorage.getItem(
      "attendanceSubjects"
    );

    return savedSubjects
      ? JSON.parse(savedSubjects)
      : defaultSubjects;

  });


  const [subjectName, setSubjectName] = useState("");

useEffect(() => {
  localStorage.setItem(
    "attendanceSubjects",
    JSON.stringify(subjects)
  );

  window.dispatchEvent(new Event("attendanceUpdated"));
}, [subjects]);


  const calculatePercentage = (attended, total) => {

    if (total === 0) return 0;

    return Math.round(
      (attended / total) * 100
    );

  };


  const addSubject = () => {

    if (subjectName.trim() === "") {
      return;
    }


    const newSubject = {

      id: Date.now(),

      name: subjectName,

      attended: 0,

      total: 0

    };


    setSubjects([
      ...subjects,
      newSubject
    ]);


    setSubjectName("");

  };


  const deleteSubject = (id) => {

    setSubjects(
      subjects.filter(
        (subject) => subject.id !== id
      )
    );

  };


  const markPresent = (id) => {

    setSubjects(

      subjects.map((subject) => {

        if (subject.id === id) {

          return {

            ...subject,

            attended: subject.attended + 1,

            total: subject.total + 1

          };

        }

        return subject;

      })

    );

  };


  const markAbsent = (id) => {

    setSubjects(

      subjects.map((subject) => {

        if (subject.id === id) {

          return {

            ...subject,

            total: subject.total + 1

          };

        }

        return subject;

      })

    );

  };


  const totalAttended = subjects.reduce(
    (sum, subject) =>
      sum + subject.attended,
    0
  );


  const totalClasses = subjects.reduce(
    (sum, subject) =>
      sum + subject.total,
    0
  );


  const overallAttendance =
    totalClasses === 0
      ? 0
      : Math.round(
          (totalAttended / totalClasses) * 100
        );


  return (

    <div className="attendance-page">


      <div className="page-header">

        <div>

          <h2>Attendance Tracker</h2>

          <p>
            Keep track of your attendance for every subject.
          </p>

        </div>


        <div className="overall-attendance">

          <FaCheckCircle />

          <div>

            <small>Overall Attendance</small>

            <strong>
              {overallAttendance}%
            </strong>

          </div>

        </div>

      </div>



      {/* Add Subject */}

      <div className="add-subject">

        <input
          type="text"
          placeholder="Enter subject name..."
          value={subjectName}
          onChange={(e) =>
            setSubjectName(e.target.value)
          }
          onKeyDown={(e) => {

            if (e.key === "Enter") {
              addSubject();
            }

          }}
        />


        <button onClick={addSubject}>

          <FaPlus />

          Add Subject

        </button>

      </div>



      {/* Attendance Cards */}

      <div className="attendance-grid">

        {subjects.map((subject) => {

          const percentage =
            calculatePercentage(
              subject.attended,
              subject.total
            );


          return (

            <div
              className="attendance-card"
              key={subject.id}
            >

              <div className="attendance-card-header">

                <div>

                  <h3>
                    {subject.name}
                  </h3>

                  <p>
                    {subject.attended} attended
                    {" / "}
                    {subject.total} classes
                  </p>

                </div>


                <button
                  className="delete-btn"
                  onClick={() =>
                    deleteSubject(subject.id)
                  }
                >

                  <FaTrash />

                </button>

              </div>



              <div className="attendance-percentage">

                <strong>
                  {percentage}%
                </strong>

                <span
                  className={
                    percentage >= 75
                      ? "status good"
                      : "status warning"
                  }
                >

                  {percentage >= 75
                    ? "Good"
                    : "Low Attendance"}

                </span>

              </div>



              <div className="attendance-progress">

                <div
                  style={{
                    width: `${percentage}%`
                  }}
                ></div>

              </div>



              <div className="attendance-actions">

                <button
                  className="present-btn"
                  onClick={() =>
                    markPresent(subject.id)
                  }
                >

                  Present

                </button>


                <button
                  className="absent-btn"
                  onClick={() =>
                    markAbsent(subject.id)
                  }
                >

                  Absent

                </button>

              </div>

            </div>

          );

        })}

      </div>

    </div>

  );

}


export default Attendance;