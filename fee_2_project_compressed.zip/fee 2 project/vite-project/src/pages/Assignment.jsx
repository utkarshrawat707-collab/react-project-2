
import { useEffect, useState } from "react";
import {
  FaPlus,
  FaTrash,
  FaCheckCircle,
  FaTasks
} from "react-icons/fa";

function Assignment() {
  const [assignments, setAssignments] = useState(() => {
    const savedAssignments = localStorage.getItem("studentAssignments");
    return savedAssignments ? JSON.parse(savedAssignments) : [];
  });

  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    localStorage.setItem(
      "studentAssignments",
      JSON.stringify(assignments)
    );

    window.dispatchEvent(new Event("assignmentsUpdated"));
  }, [assignments]);

  const addAssignment = (e) => {
    e.preventDefault();

    if (
      title.trim() === "" ||
      subject.trim() === "" ||
      dueDate === ""
    ) {
      return;
    }

    const newAssignment = {
      id: Date.now(),
      title: title.trim(),
      subject: subject.trim(),
      dueDate,
      priority,
      completed: false
    };

    setAssignments([...assignments, newAssignment]);

    setTitle("");
    setSubject("");
    setDueDate("");
    setPriority("Medium");
  };

  const toggleComplete = (id) => {
    setAssignments(
      assignments.map((assignment) => {
        if (assignment.id === id) {
          return {
            ...assignment,
            completed: !assignment.completed
          };
        }

        return assignment;
      })
    );
  };

  const deleteAssignment = (id) => {
    setAssignments(
      assignments.filter(
        (assignment) => assignment.id !== id
      )
    );
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const pendingCount = assignments.filter(
    (assignment) => !assignment.completed
  ).length;

  const completedCount = assignments.filter(
    (assignment) => assignment.completed
  ).length;

  const filteredAssignments = assignments.filter((assignment) => {
    if (filter === "Pending") {
      return !assignment.completed;
    }

    if (filter === "Completed") {
      return assignment.completed;
    }

    return true;
  });

  const isOverdue = (assignment) => {
    const due = new Date(assignment.dueDate + "T00:00:00");
    return !assignment.completed && due < today;
  };

  return (
    <div className="assignment-page">
      <div className="page-header">
        <div>
          <h2>Assignment Manager</h2>
          <p>Organize your assignments and never miss a deadline.</p>
        </div>

        <div className="assignment-header-icon">
          <FaTasks />
        </div>
      </div>

      <div className="assignment-stats">
        <div className="assignment-stat-card">
          <span>Total Assignments</span>
          <h3>{assignments.length}</h3>
        </div>

        <div className="assignment-stat-card">
          <span>Pending</span>
          <h3>{pendingCount}</h3>
        </div>

        <div className="assignment-stat-card">
          <span>Completed</span>
          <h3>{completedCount}</h3>
        </div>
      </div>

      <div className="assignment-form-card">
        <h3>Add New Assignment</h3>

        <form onSubmit={addAssignment}>
          <div className="assignment-form-grid">
            <div className="assignment-field">
              <label>Assignment Title</label>
              <input
                type="text"
                placeholder="e.g. React Project"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="assignment-field">
              <label>Subject</label>
              <input
                type="text"
                placeholder="e.g. Web Development"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
            </div>

            <div className="assignment-field">
              <label>Due Date</label>
              <input
                type="date"
                value={dueDate}
                min={new Date().toLocaleDateString("en-CA")}
                onChange={(e) => setDueDate(e.target.value)}
                required
              />
            </div>

            <div className="assignment-field">
              <label>Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>
          </div>

          <button type="submit" className="assignment-add-btn">
            <FaPlus /> Add Assignment
          </button>
        </form>
      </div>

      <div className="assignment-list-section">
        <div className="assignment-list-header">
          <h3>Your Assignments</h3>

          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            aria-label="Filter assignments"
          >
            <option value="All">All Assignments</option>
            <option value="Pending">Pending</option>
            <option value="Completed">Completed</option>
          </select>
        </div>

        {filteredAssignments.length === 0 ? (
          <div className="assignment-empty">
            <FaTasks />
            <p>No assignments found.</p>
            <span>Add a new assignment to get started.</span>
          </div>
        ) : (
          <div className="assignment-list">
            {filteredAssignments.map((assignment) => (
              <div
                className={`assignment-card ${
                  assignment.completed ? "is-completed" : ""
                }`}
                key={assignment.id}
              >
                <div className="assignment-check">
                  <input
                    type="checkbox"
                    checked={assignment.completed}
                    onChange={() => toggleComplete(assignment.id)}
                    aria-label={`Mark ${assignment.title} as completed`}
                  />
                </div>

                <div className="assignment-details">
                  <h4>{assignment.title}</h4>
                  <p>{assignment.subject}</p>

                  <div className="assignment-meta">
                    <span>Due: {assignment.dueDate}</span>

                    <span
                      className={`priority-badge priority-${assignment.priority.toLowerCase()}`}
                    >
                      {assignment.priority} Priority
                    </span>

                    {isOverdue(assignment) && (
                      <span className="overdue-badge">
                        Overdue
                      </span>
                    )}

                    {assignment.completed && (
                      <span className="completed-badge">
                        <FaCheckCircle /> Completed
                      </span>
                    )}
                  </div>
                </div>

                <button
                  className="assignment-delete-btn"
                  onClick={() => deleteAssignment(assignment.id)}
                  aria-label={`Delete ${assignment.title}`}
                  title="Delete assignment"
                >
                  <FaTrash />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Assignment;
