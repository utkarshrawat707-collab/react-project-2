import { FaBell, FaUserCircle } from "react-icons/fa";

function Navbar() {

  return (

    <header className="navbar">

      <div>
        <h1>Student Productivity Hub</h1>
        <p>Manage your academic life in one place.</p>
      </div>


      <div className="navbar-right">

        <button className="notification">
          <FaBell />
          <span></span>
        </button>

        <div className="profile">

          <FaUserCircle className="profile-icon" />

          <div>
            <strong>Student</strong>
            <small>University Student</small>
          </div>

        </div>

      </div>

    </header>

  );
}

export default Navbar;