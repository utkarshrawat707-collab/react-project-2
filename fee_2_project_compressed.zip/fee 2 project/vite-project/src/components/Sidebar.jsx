import { NavLink } from "react-router-dom";

import {
  FaHome,
  FaClipboardCheck,
  FaTasks,
  FaBook,
  FaCalendarAlt,
  FaClock,
  FaCalculator,
  FaBullseye
} from "react-icons/fa";

function Sidebar() {

  const menuItems = [
    {
      name: "Dashboard",
      path: "/",
      icon: <FaHome />
    },
    {
      name: "Attendance",
      path: "/attendance",
      icon: <FaClipboardCheck />
    },
    {
      name: "Assignments",
      path: "/assignments",
      icon: <FaTasks />
    },
    {
      name: "Notes",
      path: "/notes",
      icon: <FaBook />
    },
    {
      name: "Timetable",
      path: "/timetable",
      icon: <FaClock />
    },
    {
      name: "Calendar",
      path: "/calendar",
      icon: <FaCalendarAlt />
    },
    {
      name: "GPA Calculator",
      path: "/gpa",
      icon: <FaCalculator />
    },
    {
      name: "Daily Goals",
      path: "/goals",
      icon: <FaBullseye />
    }
  ];

  return (
    <aside className="sidebar">

      <div className="logo">
        <div className="logo-icon">SP</div>

        <div>
          <h2>StudyHub</h2>
          <p>Student Productivity</p>
        </div>
      </div>


      <nav>

        {menuItems.map((item) => (

          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              isActive ? "nav-item active" : "nav-item"
            }
          >

            <span className="nav-icon">
              {item.icon}
            </span>

            <span>
              {item.name}
            </span>

          </NavLink>

        ))}

      </nav>


      <div className="sidebar-bottom">

        <p>Stay productive 🚀</p>

      </div>

    </aside>
  );
}

export default Sidebar;